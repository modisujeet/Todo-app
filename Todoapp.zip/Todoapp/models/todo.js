const mongoose = require('mongoose');

// creating schema in database for todo list

const todoSchema = new mongoose.Schema
    ({ 
        task :{
            type : String,
            required : true
        },
        date :{
            type : String,
            required: true
        },
        selectone :{
            type : String,
            required : true
        }

    });


  const  Todo = mongoose.model('Todo', todoSchema);
  module.exports = Todo; 